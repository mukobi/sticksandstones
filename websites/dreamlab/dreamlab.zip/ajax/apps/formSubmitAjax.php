<!DOCTYPE html>
<html>
<head><script type="text/javascript">function ret(){parent.postMessage && parent.postMessage(document.body.firstChild.nodeValue,'.');}</script></head><body onload='ret()'>{"success":true,"action":"finished","data":{"message":null,"ucfid":0}}</body></html>